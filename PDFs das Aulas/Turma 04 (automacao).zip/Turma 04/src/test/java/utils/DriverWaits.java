package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class DriverWaits {

    WebDriver driver;
    WebDriverWait explicitWait;
    Wait<WebDriver> fluentWait;

    public DriverWaits(WebDriver driver) {
        this.driver = driver;
        explicitWait = new WebDriverWait(driver, Duration.ofSeconds(4));
        fluentWait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(4))
                .pollingEvery(Duration.ofSeconds(1))
                .ignoring(NoSuchElementException.class);
    }

    public WebElement esperarElementoCarregar(By byElement){
        return explicitWait.until(ExpectedConditions.visibilityOfElementLocated(byElement));
    }

    public WebElement esperarElementoClicar(WebElement element){
        return explicitWait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public WebElement tentarLocalizarElemento(By byElement){
        return fluentWait.until(tentar -> driver.findElement(byElement));
    }

}
