package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v135.page.Page;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.DriverWaits;

import java.sql.Driver;

public class TelaPrincipalPage {

    private DriverWaits driverWaits;

    //Page Factory
    @FindBy(linkText = "Melhores Atacantes do tipo Voador")
    private WebElement menuAtacantesVoador;
    @FindBy(linkText = "Melhores Atacantes do tipo Fantasma")
    private WebElement menuAtacantesFantasma;
    @FindBy(css = "input[placeholder='Search...']")
    private WebElement campoPesquisarPokemon;

    //Construtor
    public TelaPrincipalPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
        driverWaits = new DriverWaits(driver);
    }

    //Ações da Página
    public void clicarMenuAtacantes(String tipo){
        switch (tipo){
            case "voador" -> driverWaits.esperarElementoClicar(menuAtacantesVoador).click();
            case "fantasma" -> driverWaits.esperarElementoClicar(menuAtacantesFantasma).click();
            default -> Assert.fail("Tipo inexistente: " + tipo);
        }
    }

    public void pesquisarPokemon(String pokemonNome){
        campoPesquisarPokemon.sendKeys(pokemonNome);
        driverWaits.esperarElementoCarregar(By.partialLinkText(pokemonNome)).click();
    }
}
