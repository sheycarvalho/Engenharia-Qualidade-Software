package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.DriverWaits;

public class MelhoresAtacantesPage {

    WebDriver driver;
    DriverWaits driverWaits;

    //PageFactory
    @FindBy(css = "header img[title='Flying']")
    private WebElement imagemVoador;
    @FindBy(css = "header img[title='Ghost']")
    private WebElement imagemFantasma;

    //Construtor
    public MelhoresAtacantesPage(WebDriver driver) {
        this.driver = driver;
        this.driverWaits = new DriverWaits(driver);
        PageFactory.initElements(driver, this);
    }

    //Elementos
    private final By pageTitle = By.cssSelector("header[style^='background: var(--type-']");

    //Ações da Página
    public String pegarTituloPagina(){
        return driverWaits.esperarElementoCarregar(pageTitle).getText();
    }

    public boolean validarImagem(String tipo){
        switch (tipo){
            case "voador" -> {
                return imagemVoador.isDisplayed();
            }
            case "fantasma" -> {
                return imagemFantasma.isDisplayed();
            }
            default -> {
                return false;
            }
        }
    }

    public boolean validarImagemFantasma(){
        return imagemFantasma.isDisplayed();
    }
}
