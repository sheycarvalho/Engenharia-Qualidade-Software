package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v135.page.Page;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.DriverWaits;

import java.util.List;

public class PokemonStatusPage {

    WebDriver driver;
    DriverWaits driverWaits;

    //PageFactory
    @FindBy(css = "ul[class^='MovesetCard_moves'] a")
    private List<WebElement> listaMovimentos;
    @FindBy(id = "max-cp-chart")
    private WebElement tabelaPcMaximo;

    public PokemonStatusPage(WebDriver driver) {
        this.driver = driver;
        driverWaits = new DriverWaits(driver);
        PageFactory.initElements(driver,this);
    }

    //Ações da Página
    public String pegarPrimeiroGolpe(){
        return listaMovimentos.get(0).getText();
    }

    public String pegarSegundoGolpe(){
        return listaMovimentos.get(1).getText();
    }

    public void moverParaSegundoGolpe() {
        Actions actions = new Actions(driver);
        actions.moveToElement(listaMovimentos.get(1)).perform();
        actions.scrollToElement(tabelaPcMaximo).perform();
    }
}
