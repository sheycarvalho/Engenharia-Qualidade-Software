package steps;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import pages.MelhoresAtacantesPage;
import pages.PokemonStatusPage;
import pages.TelaPrincipalPage;
import utils.DriverFactory;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

public class PokemonSteps {

    WebDriver driver;
    MelhoresAtacantesPage melhoresAtacantesPage;

    @Dado("que eu acesse a página do Pokemon")
    public void que_eu_acesse_a_página_do_pokemon() {
        DriverFactory driverFactory = new DriverFactory();
        driver = driverFactory.getChromeDriver();
        driver.get("https://db.pokemongohub.net/pt");
        melhoresAtacantesPage = new MelhoresAtacantesPage(driver);
    }

    @Quando("eu acessar a tela de melhores atacantes do tipo {string}")
    public void eu_acessar_a_tela_de_melhores_atacantes(String tipo) {
        TelaPrincipalPage telaPrincipalPage = new TelaPrincipalPage(driver);
        telaPrincipalPage.clicarMenuAtacantes(tipo);
    }

    @Quando("pesquisar {string}")
    public void pesquisar(String nome) {
        TelaPrincipalPage telaPrincipalPage = new TelaPrincipalPage(driver);
        telaPrincipalPage.pesquisarPokemon(nome);
    }

    @Então("o título deve ser {string}")
    public void o_título_deve_ser(String expectedTitulo) {
        Assert.assertEquals(expectedTitulo,
                melhoresAtacantesPage.pegarTituloPagina());
    }

    @Então("o usuário deve ser encaminhado para uma nova url {string}")
    public void oUsuárioDeveSerEncaminhadoParaUmaNovaUrl(String url) {
        String expectedURL = "https://db.pokemongohub.net/pt/pokemon-list/best-per-type/" + url;
        Assert.assertEquals(expectedURL, driver.getCurrentUrl());
    }

    @Então("o ícone de pokemon {string} deve aparecer")
    public void o_ícone_de_pokemon_correto_deve_aparecer(String tipo) {
        Assert.assertTrue(melhoresAtacantesPage.validarImagem(tipo));
    }

    @Então("o primeiro movimento será {string}")
    public void o_primeiro_movimento_será(String primeiroMovimento) {
        //Validation
        PokemonStatusPage pokemonStatusPage = new PokemonStatusPage(driver);
        Assert.assertEquals(primeiroMovimento, pokemonStatusPage.pegarPrimeiroGolpe());
        pokemonStatusPage.moverParaSegundoGolpe();
    }

    @Então("os movimentos do pokemon serão apresentados")
    public void osMovimentosDoPokemonSerãoApresentados(DataTable tableMovimentos) {
        List<List<String>> listaMovimentos = tableMovimentos.asLists();

        //FOR LIST
        List<String> listProdutos = List.of("01","02", "03");
        listProdutos.forEach(System.out::println);
        for (String listProduto : listProdutos) {
            System.out.println(listProduto);
        }

        PokemonStatusPage pokemonStatusPage = new PokemonStatusPage(driver);
        Assert.assertEquals(listaMovimentos.get(1).get(0), pokemonStatusPage.pegarPrimeiroGolpe());
        Assert.assertEquals(listaMovimentos.get(1).get(1), pokemonStatusPage.pegarSegundoGolpe());
    }

    @AfterStep
    public void tirarPrint(Scenario scenario) throws IOException {
        //Screenshot
        String imageName = scenario.getName().replace(" ", "_") + System.currentTimeMillis() + ".png";
        var camera = (TakesScreenshot) driver;
        byte[] screenshot = camera.getScreenshotAs(OutputType.BYTES);
        scenario.attach(screenshot, "image/png", imageName);
        Path path = Path.of("target/screenshots");
        if (Files.exists(path)) {
            File image = camera.getScreenshotAs(OutputType.FILE);
            Files.move(image.toPath(), Path.of("target/screenshots/" + imageName), REPLACE_EXISTING);
        }
    }
    @After
    public void fechar() {
        driver.quit();
    }

}
