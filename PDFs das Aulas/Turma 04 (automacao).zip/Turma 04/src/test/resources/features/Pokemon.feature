# language: pt
# encoding: utf-8

Funcionalidade: Pokemon

  Contexto:
    Dado que eu acesse a página do Pokemon

  Esquema do Cenário: 01 - Acessar lista de Atacantes
    Quando eu acessar a tela de melhores atacantes do tipo "<tipo>"
    Então o título deve ser "<titulo>"
    E o usuário deve ser encaminhado para uma nova url "<url>"
    E o ícone de pokemon "<tipo>" deve aparecer

    Exemplos:
      | tipo     | titulo                                            | url    |
      | voador   | Melhores Atacantes do tipo Voador em Pokémon GO   | flying |
      | fantasma | Melhores Atacantes do tipo Fantasma em Pokémon GO | ghost  |

  Esquema do Cenário: 02 - Pesquisar Pokemon
    Quando pesquisar "<nome>"
    Então os movimentos do pokemon serão apresentados
      | Primeiro Golpe      | Segundo Golpe      |
      | <primeiroMovimento> | <segundoMovimento> |

    Exemplos:
      | nome       | primeiroMovimento   | segundoMovimento |
      | Pikachu    | Trovoada de Choques | Ataque Selvagem  |
      | Charmander | Arranhão            | Lança-chamas     |